# 🌍 EarthSync — PWA

Tu proyecto convertido en una Progressive Web App completa.
Funciona sin conexión, se puede instalar en cualquier dispositivo.

## Archivos

```
EarthSync/
├── index.html       ← App principal (UI + lógica PWA)
├── manifest.json    ← Manifiesto PWA (nombre, iconos, colores)
├── sw.js            ← Service Worker (caché offline, estrategias de fetch)
└── icons/
    ├── icon-72.png
    ├── icon-96.png
    ├── icon-128.png
    ├── icon-144.png
    ├── icon-152.png
    ├── icon-192.png  ← Icono principal
    ├── icon-384.png
    └── icon-512.png  ← Icono splash screen
```

## Despliegue

### Opción A — GitHub Pages (gratis)
1. Sube todos los archivos a tu repo `EarthSync`
2. Ve a **Settings → Pages → Branch: main → / (root)**
3. Tu PWA estará en `https://tuusuario.github.io/EarthSync/`

### Opción B — Netlify (gratis, recomendado)
1. Arrastra la carpeta `EarthSync/` a [netlify.com/drop](https://netlify.com/drop)
2. Listo — URL automática con HTTPS ✅

### Opción C — Vercel
```bash
npm i -g vercel
cd EarthSync
vercel --prod
```

## Requisitos PWA ✅

| Requisito              | Estado |
|------------------------|--------|
| HTTPS                  | ✅ (requerido para SW) |
| manifest.json          | ✅ |
| Service Worker         | ✅ |
| Iconos 192px + 512px   | ✅ |
| Funciona offline       | ✅ |
| Instalable             | ✅ |

## Notas

- El Service Worker usa **Stale While Revalidate** para assets propios
  y **Cache First** para Google Fonts — carga instantánea en visitas repetidas.
- El banner de instalación aparece automáticamente en Chrome/Edge/Android
  cuando se cumplen los criterios PWA.
- Para iOS: el usuario debe usar **Compartir → Agregar a pantalla de inicio**.
